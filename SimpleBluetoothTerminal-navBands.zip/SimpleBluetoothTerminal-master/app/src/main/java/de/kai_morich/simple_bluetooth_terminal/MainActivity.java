package de.kai_morich.simple_bluetooth_terminal;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.fragment.app.FragmentManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements FragmentManager.OnBackStackChangedListener {

/*    int paso = 0;
    List<String> instrucciones = new ArrayList<>();
    String msgArduino = "x";
    String pulsera = "R";
    String str = "navegar-L";
    String msg;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ListView listaInstrucciones = findViewById(R.id.instructions_list);
        List<String> instruccionesFront = new ArrayList<>();
        ArrayAdapter listAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, instruccionesFront);

        Button simularNavegacion = findViewById(R.id.buttonNavigation);
        simularNavegacion.setOnClickListener(v -> {
            instruccionesFront.clear();
            instruccionesFront.add("Inicio: Dirígete al norte por Av. Beauchef hacia Av. Almirante Blanco Encalada.");
            instruccionesFront.add("81 metros: Gira a la derecha con dirección a Av. Almirante Blanco Encalada.");
            instruccionesFront.add("350 metros: Gira levemente a la derecha con dirección a Pl. Ercilla");
            instruccionesFront.add("150 metros: Gira a la izquierda con dirección a Tupper");
            instruccionesFront.add("220 metros: Gira levemente a la derecha por El Parque");
            instruccionesFront.add("350 metros: Continúa por Av. Manuel Antonio Matta");
            instruccionesFront.add("Destino: Metro Parque O'Higgins");
            listAdapter.notifyDataSetChanged();
        });

        listaInstrucciones.setAdapter(listAdapter);

        getSupportFragmentManager().addOnBackStackChangedListener(this);
        if (savedInstanceState == null)
            getSupportFragmentManager().beginTransaction().add(R.id.fragment, new DevicesFragment(), "devices").commit();
        else
            onBackStackChanged();
    }

    @Override
    public void onBackStackChanged() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(getSupportFragmentManager().getBackStackEntryCount()>0);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
